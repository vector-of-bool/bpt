#pragma once

#include "./buffer_algorithm/copy.hpp"
#include "./buffer_algorithm/count.hpp"
#include "./buffer_algorithm/size.hpp"
#include "./buffer_algorithm/transform.hpp"
