#include <neo/functor.hpp>

#include <catch2/catch.hpp>

#include <optional>

TEST_CASE("Create a functor of a pointer") {
    std::optional<int> opt_i = 32;

    auto add_six   = [](auto i) { return i + 6; };
    auto div_2     = [](auto i) { return i / 2; };
    auto to_string = [](auto i) { return std::to_string(i); };

    auto opt_2 = opt_i | neo::fmap(add_six);
    static_assert(std::is_same_v<decltype(opt_2), std::optional<int>>);
    CHECKED_IF(opt_2) { CHECK(*opt_2 == 38); }

    auto comp  = neo::compose(add_six, div_2);
    auto opt_3 = opt_i | neo::fmap(comp);
    CHECKED_IF(opt_3) { CHECK(*opt_3 == (38 / 2)); }

    auto opt_str = opt_3 | neo::fmap(to_string);
    CHECKED_IF(opt_str) { CHECK(*opt_str == "19"); }
}
