#pragma once

#include <type_traits>

namespace neo {

template <auto V>
struct value {
    using type = decltype(V);

    static constexpr auto get_value() noexcept { return V; }

    // clang-format off
    template <typename O>
    requires(std::is_convertible_v<type&, O>)
    constexpr operator O() const noexcept(noexcept(static_cast<O>(V))) {
        return V;
    }

    template <typename O>
    requires(std::is_constructible_v<O, type&>
             && !std::is_convertible_v<type&, O>)
    constexpr explicit operator O() const noexcept(noexcept(static_cast<O>(V))) {
        return static_cast<O>(V);
    }
    // clang-format on

#define DEF_BINOP(BinOp)                                                                           \
    template <auto O>                                                                              \
    requires requires {                                                                            \
        V BinOp O;                                                                                 \
    }                                                                                              \
    friend constexpr decltype(auto) operator BinOp(value,                                          \
                                                   value<O>) noexcept(noexcept(V BinOp O)) {       \
        return neo::value<(V BinOp O)>{};                                                          \
    }                                                                                              \
    friend constexpr decltype(auto) operator BinOp(value, const type& o) noexcept(                 \
        noexcept(V BinOp V)) requires requires {                                                   \
        V BinOp V;                                                                                 \
    }                                                                                              \
    { return V BinOp o; }                                                                          \
    friend constexpr decltype(auto) operator BinOp(const type& o, value) noexcept(                 \
        noexcept(V BinOp V)) requires requires {                                                   \
        V BinOp V;                                                                                 \
    }                                                                                              \
    { return V BinOp o; }                                                                          \
    static_assert(true)

    DEF_BINOP(==);
    DEF_BINOP(!=);
    DEF_BINOP(<);
    DEF_BINOP(<=);
    DEF_BINOP(>);
    DEF_BINOP(>=);
    DEF_BINOP(+);
    DEF_BINOP(-);
    DEF_BINOP(*);
    DEF_BINOP(/);
#undef DEF_OP
};

template <auto V>
constexpr value<V> val_v{};

}  // namespace neo
