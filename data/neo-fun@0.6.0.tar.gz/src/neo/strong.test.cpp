// #include <neo/strong.hpp>

// #include <variant>

// #include <catch2/catch.hpp>

// TEST_CASE("Simple boolean") {
//     neo::boolean b = false;
//     CHECK_FALSE(b);
//     neo::boolean b2 = true;

//     b = b2;
//     CHECK(b);
//     CHECK_FALSE(!b);
//     CHECK(b == true);
//     CHECK(b != false);
//     CHECK(b >= false);
//     CHECK(int(b) == 1);

//     neo::boolean b3 = b != b2;
//     CHECK_FALSE(b3);

//     auto b4 = !b3;
//     CHECK(b4 != b3);
//     static_assert(std::is_same_v<decltype(b4), neo::boolean>);
//     auto b5 = b4 < b3;
//     // static_assert(std::is_same_v<decltype(b5), neo::boolean>);

//     // int b5 = b4;
// }
