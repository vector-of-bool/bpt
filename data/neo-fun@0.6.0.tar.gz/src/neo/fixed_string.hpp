#pragma once

#if __cpp_nontype_template_args < 201911L

#error "<neo/fixed_string.hpp> requires C++20 class types as non-type template parameters"

#else

#include <neo/value.hpp>

#include <array>
#include <cstddef>
#include <string_view>

namespace neo {

template <typename Char, std::size_t Size>
class basic_fixed_string;

template <auto String, std::size_t First = 0, std::size_t Size = String.size() - First>
struct ct_string_view;

template <typename Char, std::size_t Size>
class basic_fixed_string {
public:
    using value_type = Char;
    static constexpr std::size_t size() noexcept { return Size; }

    using array_type  = std::array<value_type, size() + 1>;
    array_type _chars = {};

    using iterator       = typename array_type::iterator;
    using const_iterator = typename array_type::const_iterator;

    constexpr basic_fixed_string()                          = default;
    constexpr basic_fixed_string(const basic_fixed_string&) = default;

    constexpr basic_fixed_string(const value_type (&arr)[Size + 1])
        : basic_fixed_string(arr, arr + Size) {}

    template <typename Iterator>
    constexpr basic_fixed_string(Iterator first, Iterator last) {
        for (auto dest = _chars.begin(); first != last; ++first, ++dest) {
            *dest = *first;
        }
    }

    constexpr iterator       begin() noexcept { return _chars.begin(); }
    constexpr iterator       end() noexcept { return begin() + size(); }
    constexpr const_iterator begin() const noexcept { return _chars.begin(); }
    constexpr const_iterator end() const noexcept { return begin() + size(); }
    constexpr const_iterator cbegin() const noexcept { return _chars.cbegin(); }
    constexpr const_iterator cend() const noexcept { return cbegin() + size(); }

    constexpr value_type&       operator[](std::size_t n) noexcept { return _chars[n]; }
    constexpr const value_type& operator[](std::size_t n) const noexcept { return _chars[n]; }

    constexpr auto data() noexcept { return _chars.data(); }
    constexpr auto data() const noexcept { return _chars.data(); }
    constexpr bool empty() const noexcept { return size() == 0; }

    template <auto Pos, auto Len>
    constexpr auto substr(value<Pos>, value<Len>) const noexcept {
        return substr<Pos, Len>();
    }

    template <auto Pos>
    constexpr auto substr(value<Pos>) const noexcept {
        return substr<Pos>();
    }

    template <std::size_t Pos, std::size_t Len = std::size_t(-1)>
    constexpr auto substr() const noexcept {
        static_assert(Pos <= size());
        constexpr auto new_size = (std::min)(size() - Pos, Len);
        using substring_type    = basic_fixed_string<value_type, new_size>;
        substring_type ret;
        auto           in = begin() + Pos;
        for (auto out = ret.begin(); out != ret.end(); ++out, ++in) {
            *out = *in;
        }
        return ret;
    }

    template <std::size_t S>
    friend constexpr bool operator==(const basic_fixed_string&                left,
                                     const basic_fixed_string<value_type, S>& right) noexcept {
        if constexpr (size() != right.size()) {
            return false;
        } else {
            auto l_it = left.begin();
            auto r_it = right.begin();
            for (; l_it != left.end(); ++l_it, ++r_it) {
                if (*l_it != *r_it) {
                    return false;
                }
            }
            return true;
        }
    }

    template <std::size_t S>
    friend constexpr bool operator==(const basic_fixed_string& left,
                                     const value_type (&arr)[S]) noexcept {
        if constexpr (size() != S - 1) {
            return false;
        } else {
            auto l_it = left.begin();
            auto r_it = arr;
            for (; l_it != left.end(); ++l_it, ++r_it) {
                if (*l_it != *r_it) {
                    return false;
                }
            }
            return true;
        }
    }

    template <std::size_t S>
    friend constexpr bool operator!=(const basic_fixed_string&                left,
                                     const basic_fixed_string<value_type, S>& right) noexcept {
        return !(left == right);
    }

    template <std::size_t S>
    friend constexpr bool operator!=(const basic_fixed_string& left,
                                     const value_type (&arr)[S]) noexcept {
        return !(left == arr);
    }

    template <std::size_t S>
    friend constexpr auto operator+(const basic_fixed_string&                left,
                                    const basic_fixed_string<value_type, S>& right) noexcept {
        constexpr std::size_t new_size = left.size() + right.size();
        using ret_type                 = basic_fixed_string<value_type, new_size>;
        ret_type ret;
        auto     out = ret.begin();
        for (auto c : left) {
            *out++ = c;
        }
        for (auto c : right) {
            *out++ = c;
        }
        return ret;
    }
};

template <typename Char, std::size_t N>
basic_fixed_string(const Char (&arr)[N]) -> basic_fixed_string<Char, N - 1>;

template <typename Char, std::size_t N>
basic_fixed_string(const basic_fixed_string<Char, N>&) -> basic_fixed_string<Char, N>;

template <std::size_t N>
using fixed_string = basic_fixed_string<char, N>;

template <auto String, std::size_t First, std::size_t Size>
struct ct_string_view {
    using fixed_string_type = decltype(String);
    using value_type        = typename fixed_string_type::value_type;

    using iterator       = typename fixed_string_type::const_iterator;
    using const_iterator = iterator;
    using size_type      = std::size_t;

    constexpr static size_type begin_idx = First;
    constexpr static size_type end_idx   = begin_idx + Size;
    constexpr static size_type npos      = size_type(-1);

    constexpr static size_type size() noexcept { return Size; }
    constexpr static bool      empty() noexcept { return size() == 0; }
    constexpr static iterator  begin() noexcept { return String.begin() + begin_idx; }
    constexpr static iterator  end() noexcept { return String.begin() + end_idx; }
    constexpr static auto      data() noexcept { return String.data() + begin_idx; }

    constexpr auto realize() const noexcept {
        return basic_fixed_string<value_type, size()>(begin(), end());
    }

    constexpr auto operator[](size_type n) const noexcept { return String[begin_idx + n]; }

    template <auto S>
    constexpr static auto remove_prefix(value<S> = {}) noexcept {
        static_assert(S <= size());
        return neo::ct_string_view<String, begin_idx + S, size() - S>();
    }

    template <auto S>
    constexpr static auto remove_suffix(value<S> = {}) noexcept {
        static_assert(S <= size());
        return ct_string_view<String, begin_idx, size() - S>();
    }

    template <auto S>
    constexpr static auto first(value<S> = {}) noexcept {
        static_assert(S <= size());
        return remove_suffix<size() - S>();
    }

    template <auto S>
    constexpr static auto last(value<S> = {}) noexcept {
        return remove_prefix<size() - S>();
    }

    template <basic_fixed_string Needle>
    constexpr static auto find(value<Needle> needle [[maybe_unused]] = {}) noexcept {
        if constexpr (size() < Needle.size()) {
            return val_v<npos>;
        } else {
            auto head = first<Needle.size()>();
            if constexpr (head != Needle) {
                constexpr auto next_found = remove_prefix<1>().find(needle);
                if constexpr (next_found == npos) {
                    return next_found;
                } else {
                    return val_v<size_type(1)> + next_found;
                }
            } else {
                return val_v<size_type(0)>;
            }
        }
    }

    template <basic_fixed_string Needle>
    constexpr static auto rfind(value<Needle> needle [[maybe_unused]] = {}) noexcept {
        if constexpr (size() < Needle.size()) {
            return val_v<npos>;
        } else {
            auto tail = last<Needle.size()>();
            if constexpr (tail == Needle) {
                return val_v<Size - Needle.size()>;
            } else {
                return remove_suffix<1>().find(needle);
            }
        }
    }

    template <basic_fixed_string Set>
    constexpr static auto find_first_of(value<Set> = {}) noexcept {
        constexpr size_type found = [] {
            std::size_t idx = 0;
            for (auto c : ct_string_view()) {
                for (auto o : Set) {
                    if (c == o) {
                        return idx;
                    }
                }
                ++idx;
            }
            return npos;
        }();
        return val_v<found>;
    }

    template <basic_fixed_string Set>
    constexpr static auto find_last_of(value<Set> = {}) noexcept {
        constexpr size_type found = [] {
            for (auto idx = Size; idx; --idx) {
                for (auto o : Set) {
                    if (ct_string_view()[idx] == o) {
                        return idx;
                    }
                }
            }
            return npos;
        }();
        return val_v<found>;
    }

    template <basic_fixed_string Set>
    constexpr static auto find_first_not_of(value<Set> = {}) noexcept {
        constexpr size_type found = [] {
            size_type idx = 0;
            for (auto c : ct_string_view()) {
                for (auto o : Set) {
                    if (c != o) {
                        return idx;
                    }
                }
                ++idx;
            }
        }();
        return val_v<found>;
    }

    template <typename Other>
    static constexpr bool equal(const Other& other) noexcept {
        if (size() != other.size()) {
            return false;
        } else {
            auto l_it = begin();
            auto r_it = other.begin();
            for (; l_it != end(); ++l_it, ++r_it) {
                if (*l_it != *r_it) {
                    return false;
                }
            }
            return true;
        }
    }

    template <size_type S>
    friend constexpr bool operator==(const ct_string_view& left,
                                     const value_type (&arr)[S]) noexcept {
        return left.equal(std::string_view(arr));
    }

    template <size_type S>
    friend constexpr bool operator!=(const ct_string_view& left,
                                     const value_type (&arr)[S]) noexcept {
        return !(left == arr);
    }

    template <size_type S>
    friend constexpr bool operator==(ct_string_view                           left,
                                     const basic_fixed_string<value_type, S>& right) noexcept {
        return left.equal(right);
    }

    template <size_type S>
    friend constexpr bool operator!=(ct_string_view                           left,
                                     const basic_fixed_string<value_type, S>& right) noexcept {
        return !(left == right);
    }
};

}  // namespace neo

#endif
