#include <neo/value.hpp>

#include <catch2/catch.hpp>

TEST_CASE("Create a simple value") {
    neo::value<77> v;
    CHECK(v == v);
    CHECK(neo::val_v<1> != neo::val_v<4>);
    CHECK(v == 77);
    CHECK(77 == v);
}
