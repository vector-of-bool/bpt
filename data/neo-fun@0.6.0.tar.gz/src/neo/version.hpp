#pragma once

// clang-format off
#ifdef __has_include
#   if __has_include(<version>)
#       include <version>
#   endif
#endif

// clang-format on
