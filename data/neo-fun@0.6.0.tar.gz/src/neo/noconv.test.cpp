#include <neo/noconv.hpp>

#include <catch2/catch.hpp>

constexpr int foo(neo::noconv<int> i) { return i.get() + 2; }
constexpr int foo(neo::noconv<int&> i) { return i.get() + 8; }
constexpr int foo(neo::noconv<float> i) { return int(i.get()) + 2; }

constexpr int bar(neo::noconv<const int&> i) { return i.get() * 2; }

static_assert(foo(3) == 5);
static_assert(foo(3) == 5);
static_assert(foo(3.1f) == 5);

TEST_CASE("With an lvalue") {
    int i = 2;
    CHECK(bar(i) == 4);

    const int u = 45;
    CHECK(bar(u) == 90);

    // CHECK(foo(i) == 10);
}
