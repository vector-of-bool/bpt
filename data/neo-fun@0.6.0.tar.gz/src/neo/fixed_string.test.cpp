
#if __cpp_nontype_template_args < 201911L
// No class-type non-type template parameter suppoet

#else

#include <neo/fixed_string.hpp>

#include <catch2/catch.hpp>

template <neo::basic_fixed_string String>
struct test_nttp_string {};

TEST_CASE("Create a basic fixed string") {
    neo::basic_fixed_string fstr = "I am another fixed string";
    CHECK(fstr == fstr);

    neo::basic_fixed_string a   = "foo";
    neo::basic_fixed_string b   = "bar";
    auto                    two = a + b;
    CHECK(two == "foobar");
}

TEST_CASE("Take a substring") {
    neo::basic_fixed_string f    = "Hello, world!";
    auto                    part = f.substr(neo::val_v<0>, neo::val_v<5>);
    CHECK(part == "Hello");
    auto part2 = f.substr(neo::val_v<7>, neo::val_v<6>);
    CHECK(part2 == "world!");
}

TEST_CASE("Create a string view") {
    constexpr neo::basic_fixed_string f = "I am a string";
    neo::ct_string_view<f>            view;
    CHECK(view == "I am a string");
    CHECK(view != "lolnope");
    CHECK_FALSE(view.empty());

    CHECK(view.remove_prefix<7>() == "string");

    CHECK(view.find<"a">() == 2);
    CHECK(view.find<"b">() == view.npos);
    CHECK(view.find<"am a">() == 2);
    CHECK(view.rfind<"string">().get_value() == 7);
    CHECK(view.find_first_of<"qter">() == 8);
    CHECK(view.find_last_of<"qter">() == 9);
}

#endif
