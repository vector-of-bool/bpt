#pragma once

#include "./fwd.hpp"
#include "./ref.hpp"
#include "./returns.hpp"

namespace neo {

namespace functor_detail {

template <typename T, typename U>
struct rebind_impl;

template <template <class> class Tmpl, typename T, typename U>
struct rebind_impl<Tmpl<T>, U> {
    using type = Tmpl<U>;
};

}  // namespace functor_detail

template <typename T>
struct functor_traits {};

template <typename T>
requires requires(T inst) {
    // Dereferenceable:
    *inst;
    // Bool-convertible
    inst ? 0 : 0;
    // Default-constructible
    T();
    // Value-constructible from the "inner type"
    T(*inst);
}
struct functor_traits<T> {
    using inner_type = std::remove_cvref_t<decltype(*ref_v<T>)>;

    template <typename U>
    using rebind_t = typename functor_detail::rebind_impl<T, U>::type;

    template <typename Func>
    using apply_inner_t = std::invoke_result_t<Func, inner_type>;

    template <typename Map>
    using fmap_t = rebind_t<apply_inner_t<Map>>;

    template <typename U, typename Func>
    static constexpr fmap_t<Func>
    fmap(Func&& fn, U&& u) noexcept(std::is_nothrow_invocable_v<Func, inner_type>) {
        using new_t = fmap_t<Func>;
        if (u) {
            return new_t(std::invoke(NEO_FWD(fn), *NEO_FWD(u)));
        } else {
            return new_t();
        }
    }
};

template <typename Fctr>
using functor_inner_t = typename functor_traits<std::remove_cvref_t<Fctr>>::inner_type;

template <typename Fctr, typename Map>
using fmap_t = typename functor_traits<std::remove_cvref_t<Fctr>>::template fmap_t<Map>;

template <typename Functor>
concept functor = requires {
    typename functor_inner_t<Functor>;
};

template <typename Functor, typename Map>
concept fmap_applicable = functor<Functor>&& requires {
    typename fmap_t<Functor, Map>;
};

template <typename Map>
class bound_fmap {
    wrap_refs_t<Map> _func;

public:
    constexpr explicit bound_fmap(Map&& fn)
        : _func(NEO_FWD(fn)) {}

    template <fmap_applicable<Map> Fctr>
    constexpr fmap_t<Fctr, Map> operator()(Fctr&& fctr) const {
        return functor_traits<std::remove_cvref_t<Fctr>>::fmap(unref(_func), NEO_FWD(fctr));
    }

    template <fmap_applicable<Map> Fctr>
    friend constexpr fmap_t<Fctr, Map> operator|(Fctr&& lhs, bound_fmap&& rhs) {
        return rhs(NEO_FWD(lhs));
    }
};

template <typename Map>
explicit bound_fmap(Map &&) -> bound_fmap<Map>;

template <typename Map>
constexpr decltype(auto) fmap(Map&& fn) noexcept {
    return bound_fmap(NEO_FWD(fn));
}

template <typename Left, typename Right>
constexpr decltype(auto) compose(Left&& lhs, Right&& rhs) noexcept {
    return [ lhs = wrap_refs_t<Left>(NEO_FWD(lhs)), rhs = wrap_refs_t<Right>(NEO_FWD(rhs)) ](
        auto&& arg) NEO_RETURNS_L(std::invoke(rhs, std::invoke(lhs, NEO_FWD(arg))));
}

}  // namespace neo
