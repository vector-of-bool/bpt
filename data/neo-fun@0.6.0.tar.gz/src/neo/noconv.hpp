#pragma once

#include <type_traits>

namespace neo {

template <typename T>
class noconv {
    T _val;

public:
    template <typename U>
    requires(std::is_same_v<std::remove_cvref_t<T>, std::remove_cvref_t<U>>&&
                 std::is_convertible_v<U&&, T>)  //
        constexpr noconv(U&& t)
        : _val((T &&) t) {}

    noconv()              = delete;
    noconv(const noconv&) = delete;

    constexpr T& get() noexcept { return _val; }
    constexpr T& get() const noexcept { return _val; }
};

}  // namespace neo
