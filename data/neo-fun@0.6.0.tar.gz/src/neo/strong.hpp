#pragma once

#include "./version.hpp"

#if __cpp_lib_three_way_comparison
#include <compare>
#endif

#include <type_traits>

namespace neo {

template <typename T, typename U>
concept same_as = std::is_same_v<T, U>;

template <typename From, typename To>
concept convertible_to = std::is_convertible_v<From, To>;

template <typename T, typename... Args>
concept constructible_from = std::is_constructible_v<T, Args...>;

/**
 * @brief It's just 'bool', but without the implicit conversions
 */
struct boolean {
    bool _val;

    /**
     * @brief Implicit conversion is only allowed from `bool` *exactly*.
     *
     * @tparam T Must deduce to 'bool'
     */
    template <convertible_to<bool> T>
    explicit(!same_as<T, bool>) constexpr boolean(T b) noexcept
        : _val(b) {}

    /**
     * @brief Permit explicit conversion to any type that can be constructed from bool.
     *
     * @tparam T Any type that can be constructed from bool
     */
    template <constructible_from<bool> T>
    constexpr explicit(!same_as<bool, T>) operator T() const noexcept {
        return T(_val);
    }

    constexpr boolean operator!() const noexcept { return !bool(*this); }

    // Decl the binary operations
    // NOTE: We can't use operator<=>, because the rewrite operators must return builtin 'bool'

#define OP(Oper)                                                                                   \
    constexpr friend boolean operator Oper(boolean left, boolean right) noexcept {                 \
        return bool(left) Oper bool(right);                                                        \
    }                                                                                              \
    constexpr friend boolean operator Oper(bool left, boolean right) noexcept {                    \
        return bool(left) Oper bool(right);                                                        \
    }                                                                                              \
    constexpr friend boolean operator Oper(boolean left, bool right) noexcept {                    \
        return bool(left) Oper bool(right);                                                        \
    }                                                                                              \
    static_assert(true)

    // OP(==);
    // OP(!=);
    // OP(>);
    // OP(<);
    // OP(>=);
    // OP(<=);

#undef OP

    constexpr boolean operator==(bool other) const noexcept { return bool(*this) == other; }
    constexpr boolean operator!=(bool other) const noexcept { return bool(*this) != other; }
    // constexpr auto    operator<=>(bool other) const noexcept { return bool(*this) <=> other; }
};

}  // namespace neo