#pragma once

namespace neo {

template <typename String>
class basic_url;

template <typename ViewType>
class basic_url_view;

}  // namespace neo
