#include <cstdint>

#include <fstream>
#include <neo/url.hpp>
#include <sstream>

int main(int, char** argv) {
    std::ifstream     infile{argv[1], std::ios::binary};
    std::stringstream strm;
    strm << infile.rdbuf();
    neo::url::try_parse(strm.str());
    return 0;
}
